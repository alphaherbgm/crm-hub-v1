export interface Employee {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: string;
  joinDate: Date;
  isActive: boolean;
}

export interface EmployeeMetrics {
  employeeId: string;
  employeeName: string;
  totalMessages: number;
  repliedMessages: number;
  avgResponseTime: number; // in minutes
  responseRate: number; // percentage
  messagesThisWeek: number;
  messagesThisMonth: number;
  platformBreakdown: Record<string, number>;
  lastActive: Date;
}

export interface TeamMetrics {
  totalMessages: number;
  totalReplies: number;
  avgResponseTime: number;
  activeEmployees: number;
  responseRate: number;
  topPerformer: string;
  messagesTrend: Array<{ date: string; count: number }>;
  platformStats: Array<{ platform: string; messages: number; replies: number }>;
}

export interface MetricsTimeframe {
  period: 'today' | 'week' | 'month' | 'quarter' | 'year';
  label: string;
  startDate: Date;
  endDate: Date;
}
