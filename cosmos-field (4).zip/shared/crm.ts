export type Platform = 'amazon' | 'ebay' | 'whatsapp' | 'telegram' | 'etsy' | 'email';

export type MessageStatus = 'unread' | 'read' | 'replied';

export interface Message {
  id: string;
  platform: Platform;
  sender: string;
  senderEmail?: string;
  subject: string;
  content: string;
  timestamp: Date;
  status: MessageStatus;
  avatar?: string;
  orderId?: string;
  productId?: string;
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  platforms: Platform[];
  totalMessages: number;
  lastContact: Date;
}

export interface PlatformStats {
  platform: Platform;
  unreadCount: number;
  totalMessages: number;
}
