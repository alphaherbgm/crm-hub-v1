export interface GmailConfig {
  clientId: string;
  apiKey: string;
  scopes: string[];
  enabled: boolean;
}

export interface GmailMessage {
  id: string;
  threadId: string;
  snippet: string;
  payload: {
    headers: Array<{
      name: string;
      value: string;
    }>;
    body?: {
      data?: string;
      size: number;
    };
    parts?: Array<{
      mimeType: string;
      body: {
        data?: string;
        size: number;
      };
    }>;
  };
  internalDate: string;
  labelIds: string[];
}

export interface GmailThread {
  id: string;
  messages: GmailMessage[];
  snippet: string;
  historyId: string;
}

export interface ParsedGmailMessage {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  date: Date;
  body: string;
  isUnread: boolean;
  labels: string[];
  snippet: string;
}

export interface GmailAuth {
  isAuthenticated: boolean;
  accessToken?: string;
  refreshToken?: string;
  expiresAt?: number;
  userEmail?: string;
}

export interface GmailLabel {
  id: string;
  name: string;
  messageListVisibility: string;
  labelListVisibility: string;
  type: string;
  messagesTotal?: number;
  messagesUnread?: number;
  threadsTotal?: number;
  threadsUnread?: number;
}

export interface SendGmailMessage {
  to: string;
  subject: string;
  body: string;
  threadId?: string;
  replyToMessageId?: string;
}
