import { useState, useMemo } from "react";
import { Sidebar } from "@/components/crm/Sidebar";
import { MessageList } from "@/components/crm/MessageList";
import { MessageDetail } from "@/components/crm/MessageDetail";
import { AutoResponseBanner } from "@/components/crm/AutoResponseBanner";
import { Message, Platform } from "@shared/crm";
import { mockMessages } from "@/lib/mock-data";
import { useAutoResponse } from "@/hooks/useAutoResponse";
import { useGmailData } from "@/hooks/useGmailData";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";

export default function CRMDashboard() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | "all">(
    "all",
  );
  const [selectedMessage, setSelectedMessage] = useState<Message | undefined>();
  const [selectedMessages, setSelectedMessages] = useState<string[]>([]);

  const gmail = useGmailData();

  const allMessages = useMemo(() => {
    // Combine mock messages with Gmail messages
    const combined = [...mockMessages, ...gmail.messages];
    return combined.sort(
      (a, b) => b.timestamp.getTime() - a.timestamp.getTime(),
    );
  }, [gmail.messages]);

  const filteredMessages = useMemo(() => {
    if (selectedPlatform === "all") {
      return allMessages;
    }
    return allMessages.filter((msg) => msg.platform === selectedPlatform);
  }, [selectedPlatform, allMessages]);

  // Set default selected message
  useMemo(() => {
    if (!selectedMessage && filteredMessages.length > 0) {
      setSelectedMessage(filteredMessages[0]);
    }
  }, [filteredMessages, selectedMessage]);

  const autoResponse = useAutoResponse(filteredMessages);

  const handleMessageToggle = (messageId: string) => {
    setSelectedMessages((prev) =>
      prev.includes(messageId)
        ? prev.filter((id) => id !== messageId)
        : [...prev, messageId],
    );
  };

  const handleReply = async (content: string) => {
    if (selectedMessage) {
      if (selectedMessage.platform === "email") {
        // Handle Gmail reply
        const success = await gmail.sendReply(
          selectedMessage.senderEmail || selectedMessage.sender,
          selectedMessage.subject,
          content,
        );

        if (success) {
          console.log("Gmail reply sent successfully");
          // Update the message status to 'replied'
          const updatedMessage = {
            ...selectedMessage,
            status: "replied" as const,
          };
          setSelectedMessage(updatedMessage);
        } else {
          console.error("Failed to send Gmail reply");
        }
      } else {
        // Handle other platform replies (mock for now)
        console.log("Sending reply:", {
          messageId: selectedMessage.id,
          content,
        });

        // Update the message status to 'replied'
        const updatedMessage = {
          ...selectedMessage,
          status: "replied" as const,
        };
        setSelectedMessage(updatedMessage);
      }
    }
  };

  return (
    <div className="h-screen flex">
      <ResizablePanelGroup direction="horizontal" className="flex-1">
        {/* Sidebar */}
        <ResizablePanel defaultSize={20} minSize={15} maxSize={25}>
          <Sidebar
            selectedPlatform={selectedPlatform}
            onPlatformSelect={setSelectedPlatform}
          />
        </ResizablePanel>

        <ResizableHandle />

        {/* Message List */}
        <ResizablePanel defaultSize={35} minSize={25} maxSize={50}>
          <div className="flex flex-col h-full">
            <AutoResponseBanner
              isProcessing={autoResponse.isProcessing}
              pendingMessages={autoResponse.pendingMessages}
              responses={autoResponse.responses}
              messages={filteredMessages}
              onApprove={autoResponse.approveResponse}
              onReject={autoResponse.rejectResponse}
            />
            <MessageList
              messages={filteredMessages}
              selectedMessage={selectedMessage}
              onMessageSelect={setSelectedMessage}
              selectedMessages={selectedMessages}
              onMessageToggle={handleMessageToggle}
            />
          </div>
        </ResizablePanel>

        <ResizableHandle />

        {/* Message Detail */}
        <ResizablePanel defaultSize={45} minSize={30}>
          {selectedMessage ? (
            <MessageDetail message={selectedMessage} onReply={handleReply} />
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">
                  No message selected
                </h3>
                <p className="text-sm">
                  Select a message from the list to view its details
                </p>
              </div>
            </div>
          )}
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
