import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  MessageSquare, 
  Reply, 
  Clock, 
  TrendingUp,
  Award,
  Activity
} from "lucide-react";
import { mockEmployeeMetrics, mockTeamMetrics } from "@/lib/mock-metrics";
import { formatDistanceToNow } from "date-fns";

export default function MetricsDashboard() {
  const teamMetrics = mockTeamMetrics;
  const employeeMetrics = mockEmployeeMetrics;

  return (
    <div className="p-6 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Team Metrics</h1>
          <p className="text-muted-foreground">Monitor employee performance and response rates</p>
        </div>
        <Badge variant="outline" className="gap-2">
          <Activity className="h-4 w-4" />
          Live Data
        </Badge>
      </div>

      {/* Team Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teamMetrics.totalMessages.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Response Rate</CardTitle>
            <Reply className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teamMetrics.responseRate}%</div>
            <p className="text-xs text-muted-foreground">+2.1% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teamMetrics.avgResponseTime}m</div>
            <p className="text-xs text-muted-foreground">-3m from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teamMetrics.activeEmployees}</div>
            <p className="text-xs text-muted-foreground">All online</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Employee Performance */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Employee Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {employeeMetrics.map((employee, index) => (
                  <div key={employee.employeeId} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-muted-foreground">#{index + 1}</span>
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>
                            {employee.employeeName.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                      </div>
                      <div>
                        <h3 className="font-semibold">{employee.employeeName}</h3>
                        <p className="text-sm text-muted-foreground">
                          Last active {formatDistanceToNow(employee.lastActive, { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-2xl font-bold">{employee.totalMessages}</p>
                        <p className="text-xs text-muted-foreground">Total Messages</p>
                      </div>
                      
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-600">{employee.repliedMessages}</p>
                        <p className="text-xs text-muted-foreground">Replied</p>
                      </div>
                      
                      <div className="text-center min-w-[100px]">
                        <p className="text-lg font-bold">{employee.responseRate}%</p>
                        <Progress value={employee.responseRate} className="w-full mt-1" />
                        <p className="text-xs text-muted-foreground mt-1">Response Rate</p>
                      </div>
                      
                      <div className="text-center">
                        <p className="text-lg font-bold">{employee.avgResponseTime}m</p>
                        <p className="text-xs text-muted-foreground">Avg Time</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Platform Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Platform Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {teamMetrics.platformStats.map((platform) => (
              <div key={platform.platform} className="p-4 border rounded-lg">
                <h3 className="font-semibold mb-2">{platform.platform}</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Messages:</span>
                    <span className="font-medium">{platform.messages}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Replies:</span>
                    <span className="font-medium text-green-600">{platform.replies}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Rate:</span>
                    <span className="font-medium">{((platform.replies / platform.messages) * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={(platform.replies / platform.messages) * 100} className="mt-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
