import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Reply, Star, Archive, Trash2, MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Message, Platform } from "@shared/crm";
import { getPlatformIcon, getPlatformColor } from "@/lib/mock-data";
import { formatDistanceToNow } from "date-fns";

interface MessageListProps {
  messages: Message[];
  selectedMessage?: Message;
  onMessageSelect: (message: Message) => void;
  selectedMessages: string[];
  onMessageToggle: (messageId: string) => void;
  className?: string;
}

export function MessageList({
  messages,
  selectedMessage,
  onMessageSelect,
  selectedMessages,
  onMessageToggle,
  className
}: MessageListProps) {
  return (
    <div className={cn("flex flex-col h-full bg-background", className)}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-4">
          <Checkbox
            checked={selectedMessages.length === messages.length && messages.length > 0}
            onCheckedChange={(checked) => {
              if (checked) {
                messages.forEach(msg => onMessageToggle(msg.id));
              } else {
                selectedMessages.forEach(id => onMessageToggle(id));
              }
            }}
          />
          <span className="text-sm text-muted-foreground">
            {messages.length} messages
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm">
            <Star className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Archive className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Message List */}
      <ScrollArea className="flex-1">
        <div className="divide-y">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex items-center gap-4 p-4 hover:bg-accent/50 cursor-pointer transition-colors",
                selectedMessage?.id === message.id && "bg-accent",
                message.status === 'unread' && "bg-unread/5"
              )}
              onClick={() => onMessageSelect(message)}
            >
              <Checkbox
                checked={selectedMessages.includes(message.id)}
                onCheckedChange={(checked) => {
                  onMessageToggle(message.id);
                }}
                onClick={(e) => e.stopPropagation()}
              />

              <Avatar className="h-10 w-10">
                <AvatarFallback className={cn("text-white text-sm", getPlatformColor(message.platform))}>
                  {message.sender.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <div className={cn("h-5 w-5 rounded-full flex items-center justify-center text-white text-xs", getPlatformColor(message.platform))}>
                    {getPlatformIcon(message.platform)}
                  </div>
                  <span className={cn(
                    "text-sm truncate",
                    message.status === 'unread' ? "font-semibold" : "font-normal"
                  )}>
                    {message.sender}
                  </span>
                  {message.status === 'replied' && (
                    <Reply className="h-3 w-3 text-replied" />
                  )}
                  <span className="text-xs text-muted-foreground ml-auto">
                    {formatDistanceToNow(message.timestamp, { addSuffix: true })}
                  </span>
                </div>
                
                <div className="flex items-center gap-2 mb-1">
                  <span className={cn(
                    "text-sm truncate flex-1",
                    message.status === 'unread' ? "font-medium" : "font-normal text-muted-foreground"
                  )}>
                    {message.subject}
                  </span>
                </div>
                
                <p className={cn(
                  "text-sm text-muted-foreground truncate",
                  message.status === 'unread' && "text-foreground/80"
                )}>
                  {message.content}
                </p>
                
                {message.orderId && (
                  <Badge variant="outline" className="mt-2 text-xs">
                    Order: {message.orderId}
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
