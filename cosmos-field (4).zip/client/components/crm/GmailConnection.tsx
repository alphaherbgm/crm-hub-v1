import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import {
  Mail,
  CheckCircle,
  XCircle,
  RefreshCw,
  Settings,
  AlertTriangle,
  Loader2,
  Key,
  Shield,
} from "lucide-react";
import { useGmailData } from "@/hooks/useGmailData";
import { formatDistanceToNow } from "date-fns";

interface GmailConnectionProps {
  onConnectionChange?: (connected: boolean) => void;
}

export function GmailConnection({ onConnectionChange }: GmailConnectionProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const gmail = useGmailData();

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      await gmail.connectGmail();
      onConnectionChange?.(true);
    } catch (error) {
      console.error("Gmail connection failed:", error);
      // The error will be displayed by the useGmailData hook
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    await gmail.disconnectGmail();
    onConnectionChange?.(false);
  };

  const handleRefresh = () => {
    gmail.refreshMessages();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 flex-wrap">
          <Mail className="h-5 w-5" />
          Gmail Integration
          {gmail.isConnected ? (
            <Badge className="gap-1 bg-green-100 text-green-700 border-green-300">
              <CheckCircle className="h-3 w-3" />
              Connected
            </Badge>
          ) : (
            <Badge variant="secondary" className="gap-1">
              <XCircle className="h-3 w-3" />
              {gmail.isConfigured ? "Disconnected" : "Demo Mode"}
            </Badge>
          )}
          {/* Version & Status Indicators */}
          <Badge
            variant="outline"
            className="text-xs bg-blue-50 border-blue-300 text-blue-700"
          >
            v2.0.{Date.now().toString().slice(-3)}
          </Badge>
          <Badge
            variant="outline"
            className="text-xs bg-green-50 border-green-300 text-green-700"
          >
            ✅ Module Loaded
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Connection Status */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm font-medium">Status</p>
            <div className="flex items-center gap-2">
              {gmail.isConnected ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-gray-400" />
              )}
              <span className="text-sm">
                {gmail.isConnected ? "Active" : "Not Connected"}
              </span>
            </div>
          </div>

          <div className="space-y-1">
            <p className="text-sm font-medium">Messages</p>
            <p className="text-sm text-muted-foreground">
              {gmail.messages.length} emails loaded
            </p>
          </div>
        </div>

        {gmail.lastSync && (
          <div className="space-y-1">
            <p className="text-sm font-medium">Last Sync</p>
            <p className="text-sm text-muted-foreground">
              {formatDistanceToNow(gmail.lastSync, { addSuffix: true })}
            </p>
          </div>
        )}

        <Separator />

        {/* Actions */}
        <div className="space-y-3">
          {!gmail.isConfigured && (
            <Alert>
              <Key className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-2">
                  <p className="font-medium">Gmail API not configured</p>
                  <p className="text-sm">
                    Currently showing demo emails. To connect real Gmail:
                  </p>
                  <ol className="list-decimal list-inside text-sm space-y-1 ml-2">
                    <li>
                      Go to{" "}
                      <a
                        href="https://console.cloud.google.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        Google Cloud Console
                      </a>
                    </li>
                    <li>Enable Gmail API for your project</li>
                    <li>Create OAuth 2.0 credentials</li>
                    <li>Add environment variables to your deployment</li>
                  </ol>
                  <div className="mt-2 text-xs text-muted-foreground">
                    Debug: Client ID ={" "}
                    {import.meta.env.VITE_GOOGLE_CLIENT_ID ? "Set" : "Not Set"},
                    API Key ={" "}
                    {import.meta.env.VITE_GOOGLE_API_KEY ? "Set" : "Not Set"}
                  </div>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {gmail.error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{gmail.error}</AlertDescription>
            </Alert>
          )}

          <div className="flex gap-2">
            {gmail.isConnected ? (
              <>
                <Button
                  onClick={handleRefresh}
                  disabled={gmail.isLoading}
                  variant="outline"
                  className="gap-2"
                >
                  {gmail.isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                  Refresh
                </Button>
                <Button
                  onClick={handleDisconnect}
                  variant="outline"
                  className="gap-2"
                >
                  <XCircle className="h-4 w-4" />
                  Disconnect
                </Button>
              </>
            ) : (
              <Button
                onClick={handleConnect}
                disabled={isConnecting || !gmail.isConfigured}
                className="gap-2"
              >
                {isConnecting ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Mail className="h-4 w-4" />
                )}
                {gmail.isConfigured ? "Connect Gmail" : "Configure API First"}
              </Button>
            )}
          </div>
        </div>

        {/* Security Note */}
        <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
          <div className="flex items-start gap-2">
            <Shield className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <p className="font-medium text-blue-700 dark:text-blue-300 mb-1">
                Secure Authentication
              </p>
              <p className="text-blue-600 dark:text-blue-400">
                We use Google's OAuth 2.0 for secure authentication. Your Gmail
                password is never stored or accessed by our application.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
