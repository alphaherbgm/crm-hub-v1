import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Bot,
  Clock,
  Shield,
  MessageSquare,
  Users,
  Save,
  AlertTriangle,
  Mail,
} from "lucide-react";
import { AISettings as AISettingsType } from "@shared/ai";
import { AIResponseService } from "@/lib/ai-service";
import { getPlatformIcon } from "@/lib/mock-data";
import { GmailConnection } from "./GmailConnection";

export default function AISettings() {
  const [settings, setSettings] = useState<AISettingsType>(
    AIResponseService.getSettings(),
  );
  const [hasChanges, setHasChanges] = useState(false);

  const updateSettings = (updates: Partial<AISettingsType>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
    setHasChanges(true);
  };

  const saveSettings = () => {
    AIResponseService.saveSettings(settings);
    setHasChanges(false);
  };

  const togglePlatform = (platform: string) => {
    const platforms = settings.autoResponsePlatforms.includes(platform)
      ? settings.autoResponsePlatforms.filter((p) => p !== platform)
      : [...settings.autoResponsePlatforms, platform];

    updateSettings({ autoResponsePlatforms: platforms });
  };

  return (
    <div className="p-6 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Bot className="h-8 w-8" />
            AI Settings
          </h1>
          <p className="text-muted-foreground">
            Configure automatic responses and AI assistance
          </p>

          {/* Gmail Integration Status Indicators */}
          <div className="flex items-center gap-2 mt-3">
            <Badge
              variant="outline"
              className="gap-1 text-green-700 border-green-300 bg-green-50"
            >
              <Mail className="h-3 w-3" />
              Gmail Integration v2.0 Active
            </Badge>
            <Badge variant="secondary" className="text-xs">
              Build: {new Date().toISOString().slice(0, 10)}
            </Badge>
            <Badge variant="outline" className="text-xs">
              Status:{" "}
              {typeof window !== "undefined" &&
              import.meta.env.VITE_GOOGLE_CLIENT_ID
                ? "Configured"
                : "Demo Mode"}
            </Badge>
          </div>
        </div>
        <Button onClick={saveSettings} disabled={!hasChanges} className="gap-2">
          <Save className="h-4 w-4" />
          Save Changes
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gmail Connection */}
        <div className="lg:col-span-2">
          <GmailConnection />
        </div>
        {/* Automatic Responses */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Automatic Responses
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="font-medium">Enable Auto-Response</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically respond to customer messages
                </p>
              </div>
              <Switch
                checked={settings.autoResponseEnabled}
                onCheckedChange={(checked) =>
                  updateSettings({ autoResponseEnabled: checked })
                }
              />
            </div>

            {settings.autoResponseEnabled && (
              <>
                <Separator />

                <div className="space-y-2">
                  <Label className="font-medium">Active Platforms</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      "amazon",
                      "ebay",
                      "whatsapp",
                      "telegram",
                      "etsy",
                      "email",
                    ].map((platform) => (
                      <Button
                        key={platform}
                        variant={
                          settings.autoResponsePlatforms.includes(platform)
                            ? "default"
                            : "outline"
                        }
                        size="sm"
                        onClick={() => togglePlatform(platform)}
                        className="justify-start gap-2"
                      >
                        <span>{getPlatformIcon(platform)}</span>
                        <span className="capitalize">{platform}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="responseDelay">
                    Response Delay (seconds)
                  </Label>
                  <Input
                    id="responseDelay"
                    type="number"
                    value={settings.responseDelay}
                    onChange={(e) =>
                      updateSettings({
                        responseDelay: parseInt(e.target.value) || 0,
                      })
                    }
                    min="0"
                    max="300"
                  />
                  <p className="text-xs text-muted-foreground">
                    Wait time before sending automatic response
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confidenceThreshold">
                    Confidence Threshold (%)
                  </Label>
                  <Input
                    id="confidenceThreshold"
                    type="number"
                    value={settings.confidenceThreshold}
                    onChange={(e) =>
                      updateSettings({
                        confidenceThreshold: parseInt(e.target.value) || 0,
                      })
                    }
                    min="0"
                    max="100"
                  />
                  <p className="text-xs text-muted-foreground">
                    Minimum confidence level to send automatic response
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-medium">Require Human Review</Label>
                    <p className="text-sm text-muted-foreground">
                      Hold responses for approval
                    </p>
                  </div>
                  <Switch
                    checked={settings.requireHumanReview}
                    onCheckedChange={(checked) =>
                      updateSettings({ requireHumanReview: checked })
                    }
                  />
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Business Hours */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Business Hours
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="font-medium">Enable Business Hours</Label>
                <p className="text-sm text-muted-foreground">
                  Only auto-respond during business hours
                </p>
              </div>
              <Switch
                checked={settings.businessHours.enabled}
                onCheckedChange={(checked) =>
                  updateSettings({
                    businessHours: {
                      ...settings.businessHours,
                      enabled: checked,
                    },
                  })
                }
              />
            </div>

            {settings.businessHours.enabled && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startTime">Start Time</Label>
                    <Input
                      id="startTime"
                      type="time"
                      value={settings.businessHours.start}
                      onChange={(e) =>
                        updateSettings({
                          businessHours: {
                            ...settings.businessHours,
                            start: e.target.value,
                          },
                        })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endTime">End Time</Label>
                    <Input
                      id="endTime"
                      type="time"
                      value={settings.businessHours.end}
                      onChange={(e) =>
                        updateSettings({
                          businessHours: {
                            ...settings.businessHours,
                            end: e.target.value,
                          },
                        })
                      }
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="font-medium">Working Days</Label>
                  <div className="flex gap-1">
                    {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(
                      (day, index) => (
                        <Button
                          key={day}
                          variant={
                            settings.businessHours.weekdays[index]
                              ? "default"
                              : "outline"
                          }
                          size="sm"
                          onClick={() => {
                            const newWeekdays = [
                              ...settings.businessHours.weekdays,
                            ];
                            newWeekdays[index] = !newWeekdays[index];
                            updateSettings({
                              businessHours: {
                                ...settings.businessHours,
                                weekdays: newWeekdays,
                              },
                            });
                          }}
                        >
                          {day}
                        </Button>
                      ),
                    )}
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Escalation Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Escalation Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="escalationKeywords">Escalation Keywords</Label>
              <Textarea
                id="escalationKeywords"
                placeholder="urgent, manager, complaint, refund..."
                value={settings.escalationKeywords.join(", ")}
                onChange={(e) => {
                  const keywords = e.target.value
                    .split(",")
                    .map((k) => k.trim())
                    .filter(Boolean);
                  updateSettings({ escalationKeywords: keywords });
                }}
                className="min-h-[80px]"
              />
              <p className="text-xs text-muted-foreground">
                Messages containing these keywords will be escalated to human
                agents
              </p>
            </div>

            <div className="space-y-2">
              <Label className="font-medium">Current Keywords</Label>
              <div className="flex flex-wrap gap-1">
                {settings.escalationKeywords.map((keyword, index) => (
                  <Badge key={index} variant="secondary" className="gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    {keyword}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Response Templates */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Response Templates
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="greeting">Greeting Template</Label>
              <Input
                id="greeting"
                value={settings.responseTemplates.greeting}
                onChange={(e) =>
                  updateSettings({
                    responseTemplates: {
                      ...settings.responseTemplates,
                      greeting: e.target.value,
                    },
                  })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="closing">Closing Template</Label>
              <Textarea
                id="closing"
                value={settings.responseTemplates.closing}
                onChange={(e) =>
                  updateSettings({
                    responseTemplates: {
                      ...settings.responseTemplates,
                      closing: e.target.value,
                    },
                  })
                }
                className="min-h-[60px]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="escalationOffer">Human Agent Offer</Label>
              <Input
                id="escalationOffer"
                value={settings.responseTemplates.escalationOffer}
                onChange={(e) =>
                  updateSettings({
                    responseTemplates: {
                      ...settings.responseTemplates,
                      escalationOffer: e.target.value,
                    },
                  })
                }
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {hasChanges && (
        <div className="fixed bottom-4 right-4">
          <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-orange-700 dark:text-orange-300">
                <AlertTriangle className="h-4 w-4" />
                <span className="text-sm font-medium">
                  You have unsaved changes
                </span>
                <Button size="sm" onClick={saveSettings} className="ml-2">
                  Save Now
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
