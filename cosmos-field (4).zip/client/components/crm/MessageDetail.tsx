import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Reply,
  Forward,
  Archive,
  Trash2,
  Star,
  MoreHorizontal,
  Send,
  Paperclip,
  Image as ImageIcon,
  Smile,
  Bot,
  Wand2,
  Edit,
  Check,
  X,
  Loader2
} from "lucide-react";
import { Message } from "@shared/crm";
import { AIResponseState } from "@shared/ai";
import { getPlatformIcon, getPlatformColor } from "@/lib/mock-data";
import { AIResponseService } from "@/lib/ai-service";
import { format } from "date-fns";

interface MessageDetailProps {
  message: Message;
  onReply: (content: string) => void;
  className?: string;
}

export function MessageDetail({ message, onReply, className }: MessageDetailProps) {
  const [replyContent, setReplyContent] = useState("");
  const [isReplying, setIsReplying] = useState(false);
  const [aiResponse, setAiResponse] = useState<AIResponseState>({
    status: 'ready',
    isEditing: false
  });

  const handleSendReply = () => {
    if (replyContent.trim()) {
      onReply(replyContent);
      setReplyContent("");
      setIsReplying(false);
      setAiResponse({ status: 'ready', isEditing: false });
    }
  };

  const generateAIResponse = async () => {
    setAiResponse({ status: 'generating', isEditing: false });

    try {
      const response = await AIResponseService.generateResponse(message);
      setAiResponse({
        status: 'ready',
        response,
        isEditing: false
      });
      setReplyContent(response.generatedResponse);
      setIsReplying(true);
    } catch (error) {
      setAiResponse({
        status: 'failed',
        error: 'Failed to generate AI response',
        isEditing: false
      });
    }
  };

  const editAIResponse = () => {
    setAiResponse(prev => ({ ...prev, isEditing: true, modifiedContent: replyContent }));
  };

  const saveAIEdit = () => {
    if (aiResponse.modifiedContent) {
      setReplyContent(aiResponse.modifiedContent);
      setAiResponse(prev => ({
        ...prev,
        status: 'modified',
        isEditing: false,
        modifiedContent: undefined
      }));
    }
  };

  const cancelAIEdit = () => {
    setAiResponse(prev => ({
      ...prev,
      isEditing: false,
      modifiedContent: undefined
    }));
  };

  const useOriginalAI = () => {
    if (aiResponse.response) {
      setReplyContent(aiResponse.response.generatedResponse);
      setAiResponse(prev => ({ ...prev, status: 'ready', isEditing: false }));
    }
  };

  return (
    <div className={cn("flex flex-col h-full bg-background", className)}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-3">
          <div className={cn("h-8 w-8 rounded-full flex items-center justify-center text-white text-sm", getPlatformColor(message.platform))}>
            {getPlatformIcon(message.platform)}
          </div>
          <div>
            <h2 className="font-semibold">{message.subject}</h2>
            <p className="text-sm text-muted-foreground capitalize">{message.platform}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm">
            <Star className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Reply className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Forward className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Archive className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Message Content */}
      <ScrollArea className="flex-1">
        <div className="p-6">
          <Card>
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className={cn("text-white", getPlatformColor(message.platform))}>
                      {message.sender.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold">{message.sender}</h3>
                    {message.senderEmail && (
                      <p className="text-sm text-muted-foreground">{message.senderEmail}</p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      {format(message.timestamp, 'PPP p')}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge 
                    variant={message.status === 'unread' ? 'default' : message.status === 'replied' ? 'secondary' : 'outline'}
                    className={cn(
                      message.status === 'unread' && "bg-unread text-unread-foreground",
                      message.status === 'replied' && "bg-replied text-replied-foreground"
                    )}
                  >
                    {message.status}
                  </Badge>
                  {message.orderId && (
                    <Badge variant="outline">
                      Order: {message.orderId}
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none">
                <p className="whitespace-pre-wrap">{message.content}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>

      {/* Reply Section */}
      <div className="border-t bg-muted/30">
        {!isReplying ? (
          <div className="p-4 space-y-3">
            <div className="flex gap-2">
              <Button
                onClick={() => setIsReplying(true)}
                className="flex-1 justify-start gap-2"
              >
                <Reply className="h-4 w-4" />
                Reply to {message.sender}
              </Button>
              <Button
                onClick={generateAIResponse}
                disabled={aiResponse.status === 'generating'}
                variant="outline"
                className="gap-2"
              >
                {aiResponse.status === 'generating' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Bot className="h-4 w-4" />
                )}
                Generate AI Response
              </Button>
            </div>

            {aiResponse.status === 'failed' && (
              <Alert variant="destructive">
                <AlertDescription>{aiResponse.error}</AlertDescription>
              </Alert>
            )}
          </div>
        ) : (
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Reply className="h-4 w-4" />
                Reply to {message.sender}
              </div>

              {aiResponse.response && (
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="gap-1">
                    <Bot className="h-3 w-3" />
                    AI Generated ({aiResponse.response.confidence}% confidence)
                  </Badge>
                  {aiResponse.status === 'modified' && (
                    <Badge variant="secondary">Modified</Badge>
                  )}
                </div>
              )}
            </div>

            {aiResponse.response && !aiResponse.isEditing && (
              <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 text-sm font-medium text-blue-700 dark:text-blue-300">
                    <Bot className="h-4 w-4" />
                    AI Suggested Response
                    <Badge variant="outline" size="sm">{aiResponse.response.suggestedTone}</Badge>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={editAIResponse}>
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={useOriginalAI}>
                      <Wand2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                {aiResponse.response.requiredActions && aiResponse.response.requiredActions.length > 0 && (
                  <div className="mb-2">
                    <p className="text-xs text-blue-600 dark:text-blue-400 mb-1">Suggested actions:</p>
                    <div className="flex gap-1 flex-wrap">
                      {aiResponse.response.requiredActions.map((action, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">{action}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {aiResponse.isEditing ? (
              <div className="space-y-2">
                <Textarea
                  placeholder="Edit AI response..."
                  value={aiResponse.modifiedContent || replyContent}
                  onChange={(e) => setAiResponse(prev => ({ ...prev, modifiedContent: e.target.value }))}
                  className="min-h-[120px] resize-none"
                  autoFocus
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={saveAIEdit} className="gap-1">
                    <Check className="h-3 w-3" />
                    Save Changes
                  </Button>
                  <Button size="sm" variant="ghost" onClick={cancelAIEdit} className="gap-1">
                    <X className="h-3 w-3" />
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <Textarea
                placeholder="Type your reply..."
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                className="min-h-[120px] resize-none"
                autoFocus
              />
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm">
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <ImageIcon className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Smile className="h-4 w-4" />
                </Button>
                {!aiResponse.response && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={generateAIResponse}
                    disabled={aiResponse.status === 'generating'}
                    className="gap-1"
                  >
                    {aiResponse.status === 'generating' ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <Bot className="h-3 w-3" />
                    )}
                    AI Assist
                  </Button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  onClick={() => {
                    setIsReplying(false);
                    setReplyContent("");
                    setAiResponse({ status: 'ready', isEditing: false });
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSendReply}
                  disabled={!replyContent.trim() || aiResponse.isEditing}
                  className="gap-2"
                >
                  <Send className="h-4 w-4" />
                  Send
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
