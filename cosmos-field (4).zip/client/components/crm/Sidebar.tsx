import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Search,
  Inbox,
  Send,
  Archive,
  Trash2,
  Settings,
  Plus,
  BarChart3,
  Bot,
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { Platform } from "@shared/crm";
import {
  platformStats,
  getPlatformIcon,
  getPlatformColor,
  getPlatformStats,
} from "@/lib/mock-data";
import { useGmailData } from "@/hooks/useGmailData";

interface SidebarProps {
  selectedPlatform: Platform | "all";
  onPlatformSelect: (platform: Platform | "all") => void;
  className?: string;
}

export function Sidebar({
  selectedPlatform,
  onPlatformSelect,
  className,
}: SidebarProps) {
  const gmail = useGmailData();
  const currentPlatformStats = getPlatformStats(gmail.messages);
  const totalUnread = currentPlatformStats.reduce(
    (sum, stat) => sum + stat.unreadCount,
    0,
  );
  const location = useLocation();

  return (
    <div
      className={cn(
        "flex flex-col h-full bg-sidebar text-sidebar-foreground",
        className,
      )}
    >
      {/* Header */}
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-xl font-bold">CRM Hub</h1>
        <p className="text-sm text-sidebar-foreground/70">
          Unified Customer Communication
        </p>

        {/* Gmail Integration Status */}
        <div className="mt-3 flex items-center gap-2">
          <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-xs text-sidebar-foreground/60">
            Gmail v2.0 • {gmail.messages.length} emails loaded
          </span>
        </div>
      </div>

      {/* Search */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sidebar-foreground/50" />
          <Input
            placeholder="Search messages..."
            className="pl-10 bg-sidebar-accent border-sidebar-border text-sidebar-foreground placeholder:text-sidebar-foreground/50"
          />
        </div>
      </div>

      {/* Navigation */}
      <div className="px-4 mb-4">
        <Button
          variant={selectedPlatform === "all" ? "default" : "ghost"}
          className={cn(
            "w-full justify-start gap-3 mb-2",
            selectedPlatform === "all"
              ? "bg-sidebar-primary text-sidebar-primary-foreground"
              : "text-sidebar-foreground hover:bg-sidebar-accent",
          )}
          onClick={() => onPlatformSelect("all")}
        >
          <Inbox className="h-4 w-4" />
          All Messages
          {totalUnread > 0 && (
            <Badge className="ml-auto bg-sidebar-primary text-sidebar-primary-foreground">
              {totalUnread}
            </Badge>
          )}
        </Button>

        <div className="space-y-1">
          <Link to="/metrics">
            <Button
              variant={location.pathname === "/metrics" ? "default" : "ghost"}
              className={cn(
                "w-full justify-start gap-3",
                location.pathname === "/metrics"
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent",
              )}
            >
              <BarChart3 className="h-4 w-4" />
              Metrics Board
            </Button>
          </Link>

          {[
            { icon: Send, label: "Sent", count: 0 },
            { icon: Archive, label: "Archived", count: 12 },
            { icon: Trash2, label: "Trash", count: 3 },
          ].map((item) => (
            <Button
              key={item.label}
              variant="ghost"
              className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent"
            >
              <item.icon className="h-4 w-4" />
              {item.label}
              {item.count > 0 && (
                <Badge variant="secondary" className="ml-auto">
                  {item.count}
                </Badge>
              )}
            </Button>
          ))}
        </div>
      </div>

      {/* Platforms */}
      <div className="px-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-sidebar-foreground/80">
            Platforms
          </h3>
          <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
            <Plus className="h-3 w-3" />
          </Button>
        </div>

        <ScrollArea className="flex-1">
          <div className="space-y-1">
            {currentPlatformStats.map((stat) => (
              <Button
                key={stat.platform}
                variant={
                  selectedPlatform === stat.platform ? "default" : "ghost"
                }
                className={cn(
                  "w-full justify-start gap-3",
                  selectedPlatform === stat.platform
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent",
                )}
                onClick={() => onPlatformSelect(stat.platform)}
              >
                <div
                  className={cn(
                    "h-6 w-6 rounded-full flex items-center justify-center text-white text-xs relative",
                    getPlatformColor(stat.platform),
                  )}
                >
                  {getPlatformIcon(stat.platform)}
                  {stat.platform === "email" && gmail.isConnected && (
                    <div
                      className="absolute -top-1 -right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-white"
                      title="Gmail Connected"
                    />
                  )}
                </div>
                <span className="capitalize">{stat.platform}</span>
                {stat.unreadCount > 0 && (
                  <Badge className="ml-auto bg-sidebar-primary text-sidebar-primary-foreground">
                    {stat.unreadCount}
                  </Badge>
                )}
              </Button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Footer */}
      <div className="mt-auto p-4 border-t border-sidebar-border space-y-2">
        <Link to="/ai-settings">
          <Button
            variant={location.pathname === "/ai-settings" ? "default" : "ghost"}
            className={cn(
              "w-full justify-start gap-3",
              location.pathname === "/ai-settings"
                ? "bg-sidebar-primary text-sidebar-primary-foreground"
                : "text-sidebar-foreground hover:bg-sidebar-accent",
            )}
          >
            <Bot className="h-4 w-4" />
            AI Settings
          </Button>
        </Link>

        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent"
        >
          <Settings className="h-4 w-4" />
          Settings
        </Button>
      </div>
    </div>
  );
}
