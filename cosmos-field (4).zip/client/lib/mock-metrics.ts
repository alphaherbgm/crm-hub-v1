import { Employee, EmployeeMetrics, TeamMetrics } from "@shared/metrics";

export const mockEmployees: Employee[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah@company.com',
    role: 'Customer Service Manager',
    joinDate: new Date('2023-01-15'),
    isActive: true
  },
  {
    id: '2',
    name: 'Mike Chen',
    email: 'mike@company.com',
    role: 'Customer Support Specialist',
    joinDate: new Date('2023-03-10'),
    isActive: true
  },
  {
    id: '3',
    name: 'Emma Rodriguez',
    email: 'emma@company.com',
    role: 'Senior Support Agent',
    joinDate: new Date('2022-11-20'),
    isActive: true
  },
  {
    id: '4',
    name: 'David Kim',
    email: 'david@company.com',
    role: 'Technical Support',
    joinDate: new Date('2023-06-01'),
    isActive: true
  }
];

export const mockEmployeeMetrics: EmployeeMetrics[] = [
  {
    employeeId: '1',
    employeeName: 'Sarah Johnson',
    totalMessages: 245,
    repliedMessages: 238,
    avgResponseTime: 15,
    responseRate: 97.1,
    messagesThisWeek: 42,
    messagesThisMonth: 168,
    platformBreakdown: {
      'amazon': 85,
      'ebay': 45,
      'email': 78,
      'whatsapp': 37
    },
    lastActive: new Date('2024-01-15T14:30:00')
  },
  {
    employeeId: '2',
    employeeName: 'Mike Chen',
    totalMessages: 189,
    repliedMessages: 175,
    avgResponseTime: 22,
    responseRate: 92.6,
    messagesThisWeek: 38,
    messagesThisMonth: 142,
    platformBreakdown: {
      'amazon': 67,
      'ebay': 52,
      'telegram': 35,
      'etsy': 35
    },
    lastActive: new Date('2024-01-15T13:45:00')
  },
  {
    employeeId: '3',
    employeeName: 'Emma Rodriguez',
    totalMessages: 312,
    repliedMessages: 295,
    avgResponseTime: 12,
    responseRate: 94.5,
    messagesThisWeek: 58,
    messagesThisMonth: 198,
    platformBreakdown: {
      'whatsapp': 125,
      'telegram': 87,
      'email': 65,
      'etsy': 35
    },
    lastActive: new Date('2024-01-15T15:15:00')
  },
  {
    employeeId: '4',
    employeeName: 'David Kim',
    totalMessages: 156,
    repliedMessages: 142,
    avgResponseTime: 18,
    responseRate: 91.0,
    messagesThisWeek: 28,
    messagesThisMonth: 112,
    platformBreakdown: {
      'amazon': 45,
      'ebay': 38,
      'email': 42,
      'whatsapp': 31
    },
    lastActive: new Date('2024-01-15T12:20:00')
  }
];

export const mockTeamMetrics: TeamMetrics = {
  totalMessages: 902,
  totalReplies: 850,
  avgResponseTime: 17,
  activeEmployees: 4,
  responseRate: 94.2,
  topPerformer: 'Sarah Johnson',
  messagesTrend: [
    { date: '2024-01-08', count: 45 },
    { date: '2024-01-09', count: 52 },
    { date: '2024-01-10', count: 48 },
    { date: '2024-01-11', count: 65 },
    { date: '2024-01-12', count: 58 },
    { date: '2024-01-13', count: 42 },
    { date: '2024-01-14', count: 38 },
    { date: '2024-01-15', count: 67 }
  ],
  platformStats: [
    { platform: 'Amazon', messages: 197, replies: 185 },
    { platform: 'eBay', messages: 135, replies: 128 },
    { platform: 'Email', messages: 185, replies: 175 },
    { platform: 'WhatsApp', messages: 193, replies: 185 },
    { platform: 'Telegram', messages: 122, replies: 115 },
    { platform: 'Etsy', messages: 70, replies: 62 }
  ]
};
