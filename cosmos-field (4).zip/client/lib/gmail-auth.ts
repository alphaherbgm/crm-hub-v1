import { GmailAuth, GmailConfig } from "@shared/gmail";

// Gmail API configuration
const GMAIL_CONFIG: GmailConfig = {
  clientId: import.meta.env.VITE_GOOGLE_CLIENT_ID || "",
  apiKey: import.meta.env.VITE_GOOGLE_API_KEY || "",
  scopes: [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/gmail.modify",
  ],
  enabled: false, // Will be enabled when API keys are provided
};

export class GmailAuthService {
  private static auth: GmailAuth = {
    isAuthenticated: false,
  };

  static getConfig(): GmailConfig {
    return GMAIL_CONFIG;
  }

  static getAuth(): GmailAuth {
    // Check localStorage for saved auth
    const saved = localStorage.getItem("gmail-auth");
    if (saved) {
      try {
        const parsedAuth = JSON.parse(saved);
        if (parsedAuth.expiresAt && parsedAuth.expiresAt > Date.now()) {
          this.auth = parsedAuth;
        } else {
          // Token expired, clear it
          this.clearAuth();
        }
      } catch (error) {
        console.error("Error parsing saved Gmail auth:", error);
        this.clearAuth();
      }
    }
    return this.auth;
  }

  static async initializeGoogleAPI(): Promise<boolean> {
    return new Promise((resolve) => {
      // Load Google API
      if (typeof window.gapi !== "undefined") {
        resolve(true);
        return;
      }

      const script = document.createElement("script");
      script.src = "https://apis.google.com/js/api.js";
      script.onload = () => {
        window.gapi.load("auth2", () => {
          window.gapi.auth2
            .init({
              client_id: GMAIL_CONFIG.clientId,
              scope: GMAIL_CONFIG.scopes.join(" "),
            })
            .then(() => {
              resolve(true);
            });
        });
      };
      script.onerror = () => resolve(false);
      document.head.appendChild(script);
    });
  }

  static async authenticate(): Promise<boolean> {
    if (!GMAIL_CONFIG.clientId) {
      throw new Error(
        "Google Client ID not configured. Please set VITE_GOOGLE_CLIENT_ID environment variable.",
      );
    }

    try {
      console.log('Starting Gmail authentication...');

      // Initialize Google API if not already done
      const apiLoaded = await this.initializeGoogleAPI();
      if (!apiLoaded) {
        throw new Error('Failed to load Google API');
      }

      console.log('Google API loaded, getting auth instance...');

      // Get auth instance
      const authInstance = window.gapi.auth2.getAuthInstance();
      if (!authInstance) {
        throw new Error('Failed to get Google Auth instance');
      }

      console.log('Starting sign-in process...');

      // Sign in
      const user = await authInstance.signIn();
      const authResponse = user.getAuthResponse();

      console.log('Sign-in successful, saving auth data...');

      this.auth = {
        isAuthenticated: true,
        accessToken: authResponse.access_token,
        expiresAt: Date.now() + authResponse.expires_in * 1000,
        userEmail: user.getBasicProfile().getEmail(),
      };

      // Save to localStorage
      localStorage.setItem("gmail-auth", JSON.stringify(this.auth));

      console.log('Gmail authentication completed successfully');
      return true;
    } catch (error) {
      console.error("Gmail authentication failed:", error);
      throw error; // Re-throw to be caught by the UI
    }
  }

  static async signOut(): Promise<void> {
    try {
      if (typeof window.gapi !== "undefined" && window.gapi.auth2) {
        const authInstance = window.gapi.auth2.getAuthInstance();
        await authInstance.signOut();
      }
    } catch (error) {
      console.error("Error signing out:", error);
    } finally {
      this.clearAuth();
    }
  }

  static clearAuth(): void {
    this.auth = { isAuthenticated: false };
    localStorage.removeItem("gmail-auth");
  }

  static async refreshToken(): Promise<boolean> {
    try {
      if (typeof window.gapi !== "undefined" && window.gapi.auth2) {
        const authInstance = window.gapi.auth2.getAuthInstance();
        const user = authInstance.currentUser.get();

        if (user.isSignedIn()) {
          const authResponse = await user.reloadAuthResponse();

          this.auth = {
            ...this.auth,
            accessToken: authResponse.access_token,
            expiresAt: Date.now() + authResponse.expires_in * 1000,
          };

          localStorage.setItem("gmail-auth", JSON.stringify(this.auth));
          return true;
        }
      }
      return false;
    } catch (error) {
      console.error("Token refresh failed:", error);
      return false;
    }
  }

  static isConfigured(): boolean {
    return Boolean(
      GMAIL_CONFIG.clientId &&
        GMAIL_CONFIG.apiKey &&
        GMAIL_CONFIG.clientId !== "" &&
        GMAIL_CONFIG.apiKey !== "",
    );
  }

  static getDemoInstructions(): string {
    return `
To connect Gmail:

1. Go to Google Cloud Console (console.cloud.google.com)
2. Create a new project or select existing one
3. Enable Gmail API
4. Create OAuth 2.0 credentials
5. Add these environment variables:
   - VITE_GOOGLE_CLIENT_ID=your_client_id
   - VITE_GOOGLE_API_KEY=your_api_key

For now, the app shows demo Gmail data.
    `.trim();
  }
}

// Extend Window interface for TypeScript
declare global {
  interface Window {
    gapi: any;
  }
}
