import {
  GmailMessage,
  ParsedGmailMessage,
  GmailThread,
  SendGmailMessage,
  GmailLabel,
} from "@shared/gmail";
import { GmailAuthService } from "./gmail-auth";
import { Message } from "@shared/crm";

export class GmailService {
  private static readonly BASE_URL = "https://gmail.googleapis.com/gmail/v1";

  static async getMessages(
    maxResults: number = 50,
  ): Promise<ParsedGmailMessage[]> {
    const auth = GmailAuthService.getAuth();

    if (!auth.isAuthenticated || !auth.accessToken) {
      return this.getDemoMessages();
    }

    try {
      // Get message list
      const listResponse = await fetch(
        `${this.BASE_URL}/users/me/messages?maxResults=${maxResults}&q=in:inbox`,
        {
          headers: {
            Authorization: `Bearer ${auth.accessToken}`,
            "Content-Type": "application/json",
          },
        },
      );

      if (!listResponse.ok) {
        if (listResponse.status === 401) {
          // Token expired, try to refresh
          const refreshed = await GmailAuthService.refreshToken();
          if (refreshed) {
            return this.getMessages(maxResults);
          }
        }
        throw new Error(`Failed to fetch messages: ${listResponse.statusText}`);
      }

      const listData = await listResponse.json();

      if (!listData.messages) {
        return [];
      }

      // Fetch details for each message
      const messages = await Promise.all(
        listData.messages.slice(0, 10).map(async (msg: { id: string }) => {
          const messageResponse = await fetch(
            `${this.BASE_URL}/users/me/messages/${msg.id}`,
            {
              headers: {
                Authorization: `Bearer ${auth.accessToken}`,
                "Content-Type": "application/json",
              },
            },
          );

          if (messageResponse.ok) {
            const messageData: GmailMessage = await messageResponse.json();
            return this.parseGmailMessage(messageData);
          }
          return null;
        }),
      );

      return messages.filter(Boolean) as ParsedGmailMessage[];
    } catch (error) {
      console.error("Error fetching Gmail messages:", error);
      return this.getDemoMessages();
    }
  }

  static parseGmailMessage(gmailMessage: GmailMessage): ParsedGmailMessage {
    const headers = gmailMessage.payload.headers;

    const getHeader = (name: string): string => {
      const header = headers.find(
        (h) => h.name.toLowerCase() === name.toLowerCase(),
      );
      return header?.value || "";
    };

    // Extract body content
    let body = "";
    if (gmailMessage.payload.body?.data) {
      body = atob(
        gmailMessage.payload.body.data.replace(/-/g, "+").replace(/_/g, "/"),
      );
    } else if (gmailMessage.payload.parts) {
      // Multi-part message, find text/plain or text/html part
      const textPart = gmailMessage.payload.parts.find(
        (part) =>
          part.mimeType === "text/plain" || part.mimeType === "text/html",
      );
      if (textPart?.body?.data) {
        body = atob(textPart.body.data.replace(/-/g, "+").replace(/_/g, "/"));
      }
    }

    // Clean up HTML if present
    if (body.includes("<")) {
      const div = document.createElement("div");
      div.innerHTML = body;
      body = div.textContent || div.innerText || "";
    }

    return {
      id: gmailMessage.id,
      threadId: gmailMessage.threadId,
      subject: getHeader("Subject"),
      from: getHeader("From"),
      to: getHeader("To"),
      date: new Date(parseInt(gmailMessage.internalDate)),
      body: body.substring(0, 500), // Limit body length for display
      isUnread: gmailMessage.labelIds.includes("UNREAD"),
      labels: gmailMessage.labelIds,
      snippet: gmailMessage.snippet,
    };
  }

  static convertToMessage(gmailMessage: ParsedGmailMessage): Message {
    // Extract sender name and email
    const fromMatch = gmailMessage.from.match(/^(.+?)\s*<(.+?)>$/) || [
      null,
      gmailMessage.from,
      gmailMessage.from,
    ];

    const senderName =
      fromMatch[1]?.trim().replace(/"/g, "") || gmailMessage.from;
    const senderEmail = fromMatch[2] || gmailMessage.from;

    return {
      id: gmailMessage.id,
      platform: "email",
      sender: senderName,
      senderEmail: senderEmail,
      subject: gmailMessage.subject || "(No Subject)",
      content: gmailMessage.body || gmailMessage.snippet,
      timestamp: gmailMessage.date,
      status: gmailMessage.isUnread ? "unread" : "read",
    };
  }

  static async sendReply(
    to: string,
    subject: string,
    body: string,
    threadId?: string,
  ): Promise<boolean> {
    const auth = GmailAuthService.getAuth();

    if (!auth.isAuthenticated || !auth.accessToken) {
      console.log("Demo mode: Would send email to:", to);
      return true; // Simulate success in demo mode
    }

    try {
      // Create email message
      const email = [
        `To: ${to}`,
        `Subject: ${subject.startsWith("Re:") ? subject : `Re: ${subject}`}`,
        "Content-Type: text/plain; charset=utf-8",
        "",
        body,
      ].join("\n");

      const encodedEmail = btoa(email)
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/, "");

      const requestBody: any = {
        raw: encodedEmail,
      };

      if (threadId) {
        requestBody.threadId = threadId;
      }

      const response = await fetch(`${this.BASE_URL}/users/me/messages/send`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${auth.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      return response.ok;
    } catch (error) {
      console.error("Error sending Gmail reply:", error);
      return false;
    }
  }

  static async getLabels(): Promise<GmailLabel[]> {
    const auth = GmailAuthService.getAuth();

    if (!auth.isAuthenticated || !auth.accessToken) {
      return this.getDemoLabels();
    }

    try {
      const response = await fetch(`${this.BASE_URL}/users/me/labels`, {
        headers: {
          Authorization: `Bearer ${auth.accessToken}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        const data = await response.json();
        return data.labels || [];
      }
    } catch (error) {
      console.error("Error fetching Gmail labels:", error);
    }

    return this.getDemoLabels();
  }

  // Demo data for when Gmail is not connected
  static getDemoMessages(): ParsedGmailMessage[] {
    return [
      {
        id: "gmail-demo-1",
        threadId: "thread-1",
        subject: "Welcome to our CRM integration!",
        from: "Sarah Johnson <sarah@example.com>",
        to: "support@yourcompany.com",
        date: new Date("2024-01-15T09:30:00"),
        body: "Hi there! I'm excited to see Gmail integrated into your CRM system. This is a demo message showing how Gmail emails will appear in your unified interface.",
        isUnread: true,
        labels: ["INBOX", "UNREAD"],
        snippet:
          "Hi there! I'm excited to see Gmail integrated into your CRM system...",
      },
      {
        id: "gmail-demo-2",
        threadId: "thread-2",
        subject: "Question about your services",
        from: "Mike Chen <mike.chen@business.com>",
        to: "info@yourcompany.com",
        date: new Date("2024-01-14T16:45:00"),
        body: "Hello, I'm interested in learning more about your services. Could you please send me a detailed brochure and pricing information? Thank you!",
        isUnread: false,
        labels: ["INBOX"],
        snippet:
          "Hello, I'm interested in learning more about your services...",
      },
      {
        id: "gmail-demo-3",
        threadId: "thread-3",
        subject: "Re: Partnership opportunity",
        from: "Emma Rodriguez <emma@partner.com>",
        to: "partnerships@yourcompany.com",
        date: new Date("2024-01-14T14:20:00"),
        body: "Thank you for your quick response! I'd like to schedule a call to discuss the partnership details further. When would be a good time for you this week?",
        isUnread: true,
        labels: ["INBOX", "UNREAD", "IMPORTANT"],
        snippet:
          "Thank you for your quick response! I'd like to schedule a call...",
      },
    ];
  }

  static getDemoLabels(): GmailLabel[] {
    return [
      {
        id: "INBOX",
        name: "INBOX",
        messageListVisibility: "show",
        labelListVisibility: "labelShow",
        type: "system",
        messagesTotal: 42,
        messagesUnread: 3,
      },
      {
        id: "SENT",
        name: "SENT",
        messageListVisibility: "show",
        labelListVisibility: "labelShow",
        type: "system",
        messagesTotal: 18,
        messagesUnread: 0,
      },
      {
        id: "DRAFT",
        name: "DRAFT",
        messageListVisibility: "show",
        labelListVisibility: "labelShow",
        type: "system",
        messagesTotal: 2,
        messagesUnread: 0,
      },
    ];
  }

  static isConfigured(): boolean {
    return GmailAuthService.isConfigured();
  }

  static getSetupInstructions(): string {
    return GmailAuthService.getDemoInstructions();
  }
}
