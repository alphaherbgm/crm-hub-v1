import { Message, Platform, PlatformStats } from "@shared/crm";
import { GmailService } from "./gmail-service";

export const mockMessages: Message[] = [
  {
    id: "1",
    platform: "amazon",
    sender: "Sarah Johnson",
    senderEmail: "sarah.j@example.com",
    subject: "Question about delivery time for order #AMZ-789012",
    content:
      "Hi, I ordered the wireless headphones 3 days ago and was wondering when they will arrive. I need them for my trip next week. Thanks!",
    timestamp: new Date("2024-01-15T10:30:00"),
    status: "unread",
    orderId: "AMZ-789012",
    productId: "B08XYZ123",
  },
  {
    id: "2",
    platform: "ebay",
    sender: "Mike Chen",
    senderEmail: "mike.chen@email.com",
    subject: "Issue with received item - vintage watch",
    content:
      "The watch I received doesn't match the description. The band is different and there are scratches not mentioned in the listing. I would like to return it.",
    timestamp: new Date("2024-01-15T09:15:00"),
    status: "replied",
    orderId: "EB-456789",
  },
  {
    id: "3",
    platform: "whatsapp",
    sender: "Emma Rodriguez",
    subject: "Order status inquiry",
    content:
      "Hey! Just checking on my order from last week. Has it shipped yet? 📦",
    timestamp: new Date("2024-01-15T08:45:00"),
    status: "read",
  },
  {
    id: "4",
    platform: "email",
    sender: "David Kim",
    senderEmail: "dkim@business.com",
    subject: "Bulk order pricing request",
    content:
      "Hello, I represent ABC Corp and we're interested in placing a bulk order of 500 units. Could you provide wholesale pricing? We're looking to establish a long-term partnership.",
    timestamp: new Date("2024-01-14T16:20:00"),
    status: "unread",
  },
  {
    id: "5",
    platform: "telegram",
    sender: "Alex Thompson",
    subject: "Product customization question",
    content:
      "Is it possible to customize the logo on the product? We need it for a corporate event.",
    timestamp: new Date("2024-01-14T14:30:00"),
    status: "read",
  },
  {
    id: "6",
    platform: "etsy",
    sender: "Jennifer Walsh",
    senderEmail: "jen.walsh@gmail.com",
    subject: "Custom order request - wedding favors",
    content:
      "I love your handmade candles! I'm getting married in March and would like to order 50 custom candles as wedding favors. Can we discuss design options and pricing?",
    timestamp: new Date("2024-01-14T11:15:00"),
    status: "replied",
  },
  {
    id: "7",
    platform: "amazon",
    sender: "Robert Brown",
    senderEmail: "rbrown@example.com",
    subject: "Defective product replacement",
    content:
      "The product arrived damaged. The packaging was intact but the item itself has a crack. I would like a replacement.",
    timestamp: new Date("2024-01-13T15:45:00"),
    status: "unread",
    orderId: "AMZ-567890",
  },
  {
    id: "8",
    platform: "whatsapp",
    sender: "Lisa Anderson",
    subject: "Thank you message",
    content:
      "Thank you so much for the quick delivery! The product is exactly what I needed. Will definitely order again! ⭐⭐⭐⭐⭐",
    timestamp: new Date("2024-01-13T13:20:00"),
    status: "read",
  },
];

export const platformStats: PlatformStats[] = [
  { platform: "amazon", unreadCount: 3, totalMessages: 15 },
  { platform: "ebay", unreadCount: 1, totalMessages: 8 },
  { platform: "whatsapp", unreadCount: 2, totalMessages: 12 },
  { platform: "telegram", unreadCount: 0, totalMessages: 5 },
  { platform: "etsy", unreadCount: 1, totalMessages: 7 },
  { platform: "email", unreadCount: 4, totalMessages: 23 },
];

// Function to get updated platform stats including Gmail
export const getPlatformStats = (
  gmailMessages: any[] = [],
): PlatformStats[] => {
  const emailUnread = gmailMessages.filter(
    (msg) => msg.status === "unread",
  ).length;
  const emailTotal = gmailMessages.length;

  return platformStats.map((stat) =>
    stat.platform === "email"
      ? {
          ...stat,
          unreadCount: stat.unreadCount + emailUnread,
          totalMessages: stat.totalMessages + emailTotal,
        }
      : stat,
  );
};

export const getPlatformIcon = (platform: Platform): string => {
  const icons: Record<Platform, string> = {
    amazon: "📦",
    ebay: "🏪",
    whatsapp: "💬",
    telegram: "✈️",
    etsy: "🎨",
    email: "✉️",
  };
  return icons[platform];
};

export const getPlatformColor = (platform: Platform): string => {
  const colors: Record<Platform, string> = {
    amazon: "bg-orange-500",
    ebay: "bg-yellow-500",
    whatsapp: "bg-green-500",
    telegram: "bg-blue-500",
    etsy: "bg-pink-500",
    email: "bg-gray-500",
  };
  return colors[platform];
};
