import { useState, useEffect } from "react";
import { Message } from "@shared/crm";
import { GmailService } from "@/lib/gmail-service";
import { GmailAuthService } from "@/lib/gmail-auth";

interface GmailDataState {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  isConnected: boolean;
  lastSync: Date | null;
}

export function useGmailData() {
  const [state, setState] = useState<GmailDataState>({
    messages: [],
    isLoading: false,
    error: null,
    isConnected: false,
    lastSync: null,
  });

  const loadGmailMessages = async () => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      const gmailMessages = await GmailService.getMessages(20);
      const messages = gmailMessages.map((gmail) =>
        GmailService.convertToMessage(gmail),
      );

      const auth = GmailAuthService.getAuth();

      setState((prev) => ({
        ...prev,
        messages,
        isLoading: false,
        isConnected: auth.isAuthenticated,
        lastSync: new Date(),
      }));
    } catch (error) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to load Gmail messages",
      }));
    }
  };

  const connectGmail = async () => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      console.log('Attempting to connect Gmail...');
      const success = await GmailAuthService.authenticate();
      if (success) {
        console.log('Gmail authentication successful, loading messages...');
        await loadGmailMessages();
      } else {
        console.log('Gmail authentication returned false');
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: "Failed to authenticate with Gmail",
        }));
      }
    } catch (error) {
      console.error('Gmail connection error:', error);
      let errorMessage = 'Gmail connection failed';

      if (error instanceof Error) {
        if (error.message.includes('not configured')) {
          errorMessage = 'Gmail API not configured. Environment variables are missing.';
        } else if (error.message.includes('Failed to load')) {
          errorMessage = 'Failed to load Google API. Please check your internet connection.';
        } else {
          errorMessage = error.message;
        }
      }

      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: errorMessage,
      }));
    }
  };

  const disconnectGmail = async () => {
    await GmailAuthService.signOut();
    setState({
      messages: [],
      isLoading: false,
      error: null,
      isConnected: false,
      lastSync: null,
    });
  };

  const sendReply = async (
    to: string,
    subject: string,
    body: string,
    threadId?: string,
  ): Promise<boolean> => {
    try {
      const success = await GmailService.sendReply(to, subject, body, threadId);
      if (success) {
        // Refresh messages after sending
        await loadGmailMessages();
      }
      return success;
    } catch (error) {
      console.error("Failed to send Gmail reply:", error);
      return false;
    }
  };

  const refreshMessages = () => {
    loadGmailMessages();
  };

  // Load Gmail messages on mount
  useEffect(() => {
    const auth = GmailAuthService.getAuth();
    if (auth.isAuthenticated) {
      loadGmailMessages();
    } else {
      // Load demo messages
      loadGmailMessages();
    }
  }, []);

  return {
    ...state,
    connectGmail,
    disconnectGmail,
    sendReply,
    refreshMessages,
    isConfigured: GmailService.isConfigured(),
    setupInstructions: GmailService.getSetupInstructions(),
  };
}
